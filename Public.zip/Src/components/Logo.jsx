import React from "react";
const Logo=()=>
{
    return(
        <h1>ede logo</h1>
    )
}
export default Logo