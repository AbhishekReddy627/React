import React from "react";
import Nav from './components/Nav'
import "./";
const App=()=>
{
    return(
    <>
<Nav/>

    </>
    )
}
export default App;