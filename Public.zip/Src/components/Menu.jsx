import React from "react";
const Menu=()=>
{
    <div>

<ul>
    <li>
        <a href="">Home</a>
    </li>
    <li>
        <a href="">Login</a>
    </li>
    <li>
        <a href="">Signup</a>
    </li>
</ul>

    </div>
}
export default Menu;