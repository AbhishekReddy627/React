import React from "react";

const Logo=()=>{
    return(
        <img> 
    )
}
export default Logo;